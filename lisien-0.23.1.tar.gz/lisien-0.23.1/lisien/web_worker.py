from pyscript import sync

from lisien.proxy.routine import worker_subroutine
